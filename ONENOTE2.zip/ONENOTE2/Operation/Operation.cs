﻿using System;
using System.Windows.Forms;

namespace Operation
{
    public class Operation
    {

        
    }
}
