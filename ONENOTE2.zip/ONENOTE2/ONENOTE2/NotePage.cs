﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ONENOTE2
{
    class NotePage
    {
        private String name;      //该笔记页的名称
        private String path;     //该笔记页的储存位置
        
        
    }
}
